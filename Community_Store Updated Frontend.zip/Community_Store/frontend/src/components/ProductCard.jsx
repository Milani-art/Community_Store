import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ShieldCheck, Leaf, Star, MapPin, Heart, ArrowUpRight } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

export default function ProductCard({product}) {
  const {addToCart}=useCart(); const toast=useToast();
  const [liked,setLiked]=useState(()=>JSON.parse(localStorage.getItem('cs_wishlist')||'[]').includes(String(product.id)));
  const toggle=(e)=>{e.preventDefault();e.stopPropagation();const all=JSON.parse(localStorage.getItem('cs_wishlist')||'[]');const next=all.includes(String(product.id))?all.filter(x=>x!==String(product.id)):[...all,String(product.id)];localStorage.setItem('cs_wishlist',JSON.stringify(next));setLiked(!liked)};
  const add=(e)=>{e.preventDefault();e.stopPropagation();addToCart(product);toast.success('Added to your cart.')};
  return <article className="product-card">
    <Link to={`/products/${product.id}`} className="pc-image">
      {product.imageUrl?<img src={product.imageUrl} alt={product.title} loading="lazy"/>:<div className="pc-placeholder"><ShoppingBag size={34}/><span>Community find</span></div>}
      {product.ecoFriendly&&<span className="pc-eco"><Leaf size={12}/> Pre-loved</span>}
      <button className={`pc-heart ${liked?'liked':''}`} onClick={toggle} aria-label="Save listing"><Heart size={17} fill={liked?'currentColor':'none'}/></button>
      <span className="pc-arrow"><ArrowUpRight size={17}/></span>
    </Link>
    <div className="pc-body">
      <div className="pc-meta"><span>{product.category?.replace(/_/g,' ')||'Community'}</span><span>{product.conditionName||'Good'}</span></div>
      <Link to={`/products/${product.id}`} className="pc-title">{product.title}</Link>
      <div className="pc-seller"><span className="pc-avatar">{product.seller?.fullName?.charAt(0)?.toUpperCase()||'C'}</span><span>{product.seller?.fullName||'Community seller'}</span>{product.seller?.verified&&<ShieldCheck size={14}/>}<span className="pc-rating"><Star size={13} fill="currentColor"/>{Number(product.seller?.rating||0).toFixed(1)}</span></div>
      <div className="pc-bottom"><div><small><MapPin size={11}/> {product.location||'Campus pickup'}</small><strong>R {Number(product.price||0).toFixed(2)}</strong></div><button disabled={product.available===false} onClick={add}>{product.available===false?'Sold':<><ShoppingBag size={16}/> Add</>}</button></div>
    </div>
  </article>
}
