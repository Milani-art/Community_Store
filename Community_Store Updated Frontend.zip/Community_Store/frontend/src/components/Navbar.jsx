import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Search, ShoppingBag, PlusCircle, ShieldCheck, User, LogOut, LogIn, Menu, X, Store } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';
import { AUTH_EXPIRED_EVENT, isTokenExpired } from '../services/api';
import AuthModal from './AuthModal';

const Navbar = () => {
  const { user, token, logout } = useAuth();
  const { totalCount } = useCart();
  const toast = useToast();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const logoutRef = useRef(logout);
  logoutRef.current = logout;

  const handleSessionExpired = useCallback(() => {
    logoutRef.current();
    toast.info('Your session has expired. Please sign in again.');
    setShowAuthModal(true);
  }, [toast]);

  useEffect(() => {
    window.addEventListener(AUTH_EXPIRED_EVENT, handleSessionExpired);
    return () => window.removeEventListener(AUTH_EXPIRED_EVENT, handleSessionExpired);
  }, [handleSessionExpired]);

  useEffect(() => {
    if (token && isTokenExpired(token)) handleSessionExpired();
  }, [token, handleSessionExpired]);

  const handleLogout = () => {
    logout();
    toast.info('You have been signed out.');
    navigate('/');
    setMenuOpen(false);
  };

  const firstName = user?.fullName?.split(' ')[0] || 'Account';

  return (
    <>
      <header className="cs-nav">
        <div className="cs-nav-inner">
          <Link to="/" className="cs-brand" onClick={() => setMenuOpen(false)}>
            <img src="/logo.svg" alt="CommunityStore" />
            <span>Community<span>Store</span></span>
          </Link>

          <div className="cs-search">
            <Search size={18} />
            <input
              aria-label="Search marketplace"
              placeholder="Search textbooks, tech, services…"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                  navigate(`/marketplace?search=${encodeURIComponent(e.currentTarget.value.trim())}`);
                }
              }}
            />
          </div>

          <button className="cs-mobile-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
            {menuOpen ? <X /> : <Menu />}
          </button>

          <nav className={`cs-nav-menu ${menuOpen ? 'is-open' : ''}`}>
            <NavLink to="/marketplace" onClick={() => setMenuOpen(false)}>Shop</NavLink>
            <NavLink to="/bulletin" onClick={() => setMenuOpen(false)}>Community</NavLink>
            {user && <NavLink to="/sell" className="cs-sell-link" onClick={() => setMenuOpen(false)}><PlusCircle size={17}/> Sell</NavLink>}
            {user?.role === 'ADMIN' && <NavLink to="/admin" onClick={() => setMenuOpen(false)}>Admin</NavLink>}
            <Link to="/cart" className="cs-cart-link" onClick={() => setMenuOpen(false)}>
              <ShoppingBag size={20}/><span>Cart</span>{totalCount > 0 && <b>{totalCount > 99 ? '99+' : totalCount}</b>}
            </Link>
            {user ? (
              <div className="cs-account-actions">
                <Link to="/dashboard" className="cs-account" onClick={() => setMenuOpen(false)}>
                  <span className="avatar">{user.fullName?.charAt(0)?.toUpperCase() || <User size={16}/>}</span>
                  <span>{firstName}</span>{user.verified && <ShieldCheck size={15}/>}
                </Link>
                <button className="icon-btn" onClick={handleLogout} title="Sign out"><LogOut size={18}/></button>
              </div>
            ) : (
              <button className="cs-login" onClick={() => { setShowAuthModal(true); setMenuOpen(false); }}><LogIn size={17}/> Sign in</button>
            )}
          </nav>
        </div>
      </header>
      <div className="mobile-bottom-nav">
        <Link to="/"><Store size={19}/><span>Home</span></Link>
        <Link to="/marketplace"><Search size={19}/><span>Shop</span></Link>
        <Link to="/cart"><ShoppingBag size={19}/><span>Cart</span>{totalCount > 0 && <b>{totalCount}</b>}</Link>
        <Link to={user ? "/dashboard" : "/"}><User size={19}/><span>Account</span></Link>
      </div>
      {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
    </>
  );
};

export default Navbar;
