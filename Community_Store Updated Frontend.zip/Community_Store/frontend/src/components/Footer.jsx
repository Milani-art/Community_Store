import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Mail, ShieldCheck, Leaf, Heart, ArrowUpRight } from 'lucide-react';

export default function Footer(){
 return <footer className="cs-footer">
  <div className="footer-main">
   <div className="footer-brand"><Link to="/" className="footer-logo"><img src="/logo.svg" alt=""/> <span>Community<span>Store</span></span></Link><p>A local-first marketplace for students, neighbors and small community sellers.</p><div className="footer-social"><button><Instagram size={17}/></button><button><Facebook size={17}/></button><button><Mail size={17}/></button></div></div>
   <div><h3>Explore</h3><Link to="/marketplace">Marketplace</Link><Link to="/bulletin">Community board</Link><Link to="/sell">Sell something</Link><Link to="/dashboard">My account</Link></div>
   <div><h3>Built around trust</h3><span><ShieldCheck size={16}/> Verified accounts</span><span><Leaf size={16}/> Reuse & sustainability</span><span><Heart size={16}/> People-first marketplace</span></div>
   <div className="footer-note"><span className="eyebrow">COMMUNITYSTORE 2026</span><h3>Good things travel better nearby.</h3><Link to="/marketplace">Start exploring <ArrowUpRight size={16}/></Link></div>
  </div>
  <div className="footer-bottom"><span>© 2026 CommunityStore · Academic project</span><span>Made for campus & the neighborhood</span></div>
 </footer>
}
