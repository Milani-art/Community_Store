import React, { useEffect, useMemo, useState } from 'react';
import { Search, Leaf, X, SlidersHorizontal, Grid2X2, List, ArrowDownUp, Sparkles, BookOpen, Laptop, Shirt, Home as HomeIcon, HandHeart, MoreHorizontal } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { productApi, getErrorMessage } from '../services/api';

const CATEGORIES = [
  ['ALL','Everything',Sparkles],['TEXTBOOKS','Books',BookOpen],['ELECTRONICS','Tech',Laptop],
  ['CLOTHING','Style',Shirt],['SERVICES','Services',HandHeart],['HOUSING','Housing',HomeIcon],['ECO_FRIENDLY','Eco',Leaf],['OTHER','Other',MoreHorizontal]
];

export default function Marketplace(){
  const [params]=useSearchParams();
  const [products,setProducts]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState('');
  const [query,setQuery]=useState(params.get('search')||''),[active,setActive]=useState('ALL'),[eco,setEco]=useState(false),[sort,setSort]=useState('recent'),[view,setView]=useState('grid');
  useEffect(()=>{let cancelled=false;const load=async()=>{setLoading(true);setError('');try{const res=active==='ALL'?await productApi.getAll():await productApi.getByCategory(active);if(!cancelled&&res.data.success)setProducts(res.data.data)}catch(e){if(!cancelled)setError(getErrorMessage(e,'Could not load marketplace.'))}finally{if(!cancelled)setLoading(false)}};load();return()=>{cancelled=true}},[active]);
  const visible=useMemo(()=>{const q=query.trim().toLowerCase();let arr=products.filter(p=>(!eco||p.ecoFriendly)&&(!q||`${p.title} ${p.description||''} ${p.seller?.fullName||''}`.toLowerCase().includes(q)));if(sort==='price-low')arr.sort((a,b)=>Number(a.price)-Number(b.price));if(sort==='price-high')arr.sort((a,b)=>Number(b.price)-Number(a.price));return arr},[products,query,eco,sort]);
  return <div className="marketplace-page">
    <div className="market-hero"><div><span className="eyebrow">THE COMMUNITY SHELF</span><h1>Find something worth passing on.</h1><p>Textbooks, tech, services and good finds shared by people around your campus and neighborhood.</p></div><div className="market-hero-stats"><b>{products.length || '—'}<small>fresh listings</small></b><b>Local<small>community first</small></b></div></div>
    <div className="category-scroller">{CATEGORIES.map(([v,l,Icon])=><button key={v} className={active===v?'active':''} onClick={()=>setActive(v)}><Icon size={17}/>{l}</button>)}</div>
    <div className="market-controls"><label className="market-search"><Search size={19}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search the shelf…"/>{query&&<button onClick={()=>setQuery('')}><X size={16}/></button>}</label><div className="market-control-actions"><label><ArrowDownUp size={16}/><select value={sort} onChange={e=>setSort(e.target.value)}><option value="recent">Recently added</option><option value="price-low">Lowest price</option><option value="price-high">Highest price</option></select></label><button className={eco?'filter-on':''} onClick={()=>setEco(!eco)}><Leaf size={16}/> Eco</button><div className="view-toggle"><button className={view==='grid'?'on':''} onClick={()=>setView('grid')}><Grid2X2 size={17}/></button><button className={view==='list'?'on':''} onClick={()=>setView('list')}><List size={17}/></button></div></div></div>
    <div className="results-line"><span><b>{visible.length}</b> finds {query&&<>for “{query}”</>}</span><span><SlidersHorizontal size={15}/> {active==='ALL'?'All categories':active.replace(/_/g,' ')}</span></div>
    {loading?<div className="skeleton-grid">{Array.from({length:8}).map((_,i)=><div className="skeleton-card" key={i}/>)}</div>:error?<div className="state-message state-error"><p>{error}</p><button className="secondary-btn" onClick={()=>location.reload()}>Try again</button></div>:visible.length===0?<div className="empty-market"><Sparkles size={30}/><h2>No finds here yet.</h2><p>Try another search or category, or be the first to list something.</p></div>:<div className={view==='grid'?'market-grid':'market-list'}>{visible.map(p=><ProductCard key={p.id} product={p}/>)}</div>}
  </div>
}
