import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle2, ArrowRight, PackageCheck, ShoppingBag, ShieldCheck } from 'lucide-react';

const money = (n) => `R ${Number(n || 0).toFixed(2)}`;

export default function OrderSuccess() {
  const { state } = useLocation();
  const order = state?.order;
  return (
    <div className="success-page">
      <div className="success-orbit"><CheckCircle2 size={54}/></div>
      <span className="eyebrow">ORDER CONFIRMED</span>
      <h1>Nice one. Your order is in.</h1>
      <p className="success-lead">The community marketplace has recorded your purchase. Keep the details below for your handover.</p>
      <div className="success-card">
        <div className="success-card-top"><div><span>ORDER NUMBER</span><strong>#{order?.id || '—'}</strong></div><PackageCheck size={32}/></div>
        <div className="summary-line"><span>Payment</span><strong>{order?.paymentMethod || 'Selected method'}</strong></div>
        <div className="summary-line"><span>Status</span><strong>{order?.status || 'COMPLETED'}</strong></div>
        <div className="summary-total"><span>Total</span><strong>{money(order?.totalAmount)}</strong></div>
      </div>
      <div className="success-actions"><Link className="primary-btn" to="/dashboard">View my orders <ArrowRight size={18}/></Link><Link className="secondary-btn" to="/marketplace"><ShoppingBag size={17}/> Keep shopping</Link></div>
      <div className="success-trust"><ShieldCheck size={19}/><span>Shop local · meet safely · keep the community moving</span></div>
    </div>
  );
}
