import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Minus, Plus, Trash2, ShieldCheck, MapPin, ShoppingBag, Sparkles } from 'lucide-react';
import { useCart } from '../context/CartContext';

const money = (n) => `R ${Number(n || 0).toFixed(2)}`;

export default function CartPage() {
  const { cart, cartTotal, updateQuantity, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();
  const serviceFee = cartTotal > 0 ? 0 : 0;

  if (!cart.length) {
    return (
      <div className="empty-page">
        <div className="empty-art"><ShoppingBag size={48}/><Sparkles size={22}/></div>
        <span className="eyebrow">YOUR BAG</span>
        <h1>Your cart is taking a breather.</h1>
        <p>Browse community listings and save a few good finds here when you're ready.</p>
        <Link className="primary-btn" to="/marketplace">Explore marketplace <ArrowRight size={18}/></Link>
      </div>
    );
  }

  return (
    <div className="shop-page">
      <div className="page-heading-row">
        <div><span className="eyebrow">YOUR BAG</span><h1>Ready when you are.</h1><p>{cart.length} listing{cart.length === 1 ? '' : 's'} · {cart.reduce((a,b)=>a+b.quantity,0)} item{cart.reduce((a,b)=>a+b.quantity,0)===1?'':'s'}</p></div>
        <button className="text-button" onClick={clearCart}>Clear cart</button>
      </div>

      <div className="cart-layout">
        <section className="cart-list">
          {cart.map(({ product, quantity }) => (
            <article className="cart-row" key={product.id}>
              <Link to={`/products/${product.id}`} className="cart-thumb">
                {product.imageUrl ? <img src={product.imageUrl} alt="" /> : <ShoppingBag size={28}/>}
              </Link>
              <div className="cart-row-main">
                <div className="cart-row-top">
                  <div>
                    <span className="tiny-label">{product.category?.replace(/_/g,' ')}</span>
                    <Link to={`/products/${product.id}`} className="cart-title">{product.title}</Link>
                    <p>{product.seller?.fullName || 'Community seller'} · <MapPin size={12}/> {product.location || 'Campus pickup'}</p>
                  </div>
                  <strong>{money(product.price * quantity)}</strong>
                </div>
                <div className="cart-row-bottom">
                  <div className="quantity-control">
                    <button onClick={() => updateQuantity(product.id, quantity - 1)} aria-label="Decrease quantity"><Minus size={15}/></button>
                    <b>{quantity}</b>
                    <button onClick={() => updateQuantity(product.id, quantity + 1)} aria-label="Increase quantity"><Plus size={15}/></button>
                  </div>
                  <span>{money(product.price)} each</span>
                  <button className="remove-btn" onClick={() => removeFromCart(product.id)}><Trash2 size={15}/> Remove</button>
                </div>
              </div>
            </article>
          ))}
        </section>

        <aside className="summary-card">
          <span className="eyebrow">ORDER SUMMARY</span>
          <div className="summary-line"><span>Items</span><strong>{money(cartTotal)}</strong></div>
          <div className="summary-line"><span>Community delivery</span><strong>Free</strong></div>
          <div className="summary-line"><span>Service fee</span><strong>{money(serviceFee)}</strong></div>
          <div className="summary-total"><span>Total</span><strong>{money(cartTotal + serviceFee)}</strong></div>
          <button className="primary-btn full" onClick={() => navigate('/checkout')}>Continue to checkout <ArrowRight size={18}/></button>
          <div className="trust-mini"><ShieldCheck size={18}/><span><b>Buyer protection</b><small>Your order is recorded securely.</small></span></div>
        </aside>
      </div>
    </div>
  );
}
