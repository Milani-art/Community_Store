import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ShieldCheck, Smartphone, Banknote, CreditCard, CheckCircle2, LockKeyhole, ShoppingBag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { orderApi, getErrorMessage } from '../services/api';
import { useToast } from '../context/ToastContext';

const money = (n) => `R ${Number(n || 0).toFixed(2)}`;

export default function Checkout() {
  const { user } = useAuth();
  const { cart, cartTotal, clearCart } = useCart();
  const toast = useToast();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState('SNAPSCAN');
  const [submitting, setSubmitting] = useState(false);

  const placeOrder = async () => {
    if (!user) return toast.info('Please sign in before placing an order.');
    if (!cart.length) return navigate('/cart');
    setSubmitting(true);
    try {
      const payload = { items: cart.map(i => ({ productId: i.product.id, quantity: i.quantity })), paymentMethod };
      const res = await orderApi.create(payload);
      if (res.data.success) {
        clearCart();
        navigate('/order-success', { state: { order: res.data.data } });
      } else toast.error(res.data.message || 'Could not place order.');
    } catch (err) {
      toast.error(getErrorMessage(err, 'Could not place your order.'));
    } finally { setSubmitting(false); }
  };

  if (!cart.length) return <div className="empty-page"><ShoppingBag size={48}/><h1>Your cart is empty.</h1><Link className="primary-btn" to="/marketplace">Shop now <ArrowRight size={18}/></Link></div>;

  return (
    <div className="checkout-page">
      <Link to="/cart" className="back-link"><ArrowLeft size={17}/> Back to cart</Link>
      <div className="checkout-head"><span className="eyebrow">CHECKOUT</span><h1>A simple, local checkout.</h1><p>Confirm your payment preference and place your community order.</p></div>
      <div className="checkout-layout">
        <div className="checkout-main">
          {!user && <div className="checkout-alert"><LockKeyhole size={20}/><div><b>Sign in to continue</b><p>Your order needs an authenticated CommunityStore account.</p></div><Link to="/" className="secondary-btn">Sign in</Link></div>}
          <section className="checkout-card">
            <div className="section-title"><span className="step">1</span><div><h2>Pickup & handover</h2><p>Most community listings are arranged for local/campus collection.</p></div></div>
            <div className="pickup-box"><span className="pickup-icon">📍</span><div><b>Community pickup</b><p>Coordinate the exact meeting point with the seller after ordering.</p></div><CheckCircle2 size={19}/></div>
          </section>
          <section className="checkout-card">
            <div className="section-title"><span className="step">2</span><div><h2>Payment method</h2><p>Choose how you'd like the order recorded.</p></div></div>
            <div className="payment-grid">
              {[
                ['SNAPSCAN','SnapScan','Fast mobile payment',Smartphone],
                ['PAYFAST','PayFast','Online payment',CreditCard],
                ['CASH_ON_PICKUP','Cash on pickup','Pay when you meet',Banknote]
              ].map(([value,label,desc,Icon]) => (
                <button key={value} className={`payment-option ${paymentMethod===value?'selected':''}`} onClick={()=>setPaymentMethod(value)}>
                  <Icon size={21}/><span><b>{label}</b><small>{desc}</small></span>{paymentMethod===value && <CheckCircle2 className="payment-check" size={18}/>}
                </button>
              ))}
            </div>
          </section>
          <section className="checkout-card">
            <div className="section-title"><span className="step">3</span><div><h2>Review items</h2><p>Everything in your cart will be included.</p></div></div>
            {cart.map(({product,quantity})=><div className="checkout-item" key={product.id}>{product.imageUrl?<img src={product.imageUrl} alt=""/>:<div className="mini-product"><ShoppingBag size={18}/></div>}<span><b>{product.title}</b><small>Qty {quantity}</small></span><strong>{money(product.price*quantity)}</strong></div>)}
          </section>
        </div>
        <aside className="summary-card checkout-summary">
          <span className="eyebrow">FINAL TOTAL</span>
          <div className="summary-line"><span>Subtotal</span><strong>{money(cartTotal)}</strong></div>
          <div className="summary-line"><span>Pickup</span><strong>Free</strong></div>
          <div className="summary-total"><span>Pay</span><strong>{money(cartTotal)}</strong></div>
          <button className="primary-btn full" disabled={!user || submitting} onClick={placeOrder}>{submitting?'Placing order…':'Place order'} <ArrowRight size={18}/></button>
          <div className="secure-note"><ShieldCheck size={18}/><span><b>CommunityStore protection</b><small>Order details are saved to your account.</small></span></div>
        </aside>
      </div>
    </div>
  );
}
