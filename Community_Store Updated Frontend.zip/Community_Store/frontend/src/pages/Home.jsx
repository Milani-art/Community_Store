import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowDownUp, ArrowRight, BadgeCheck, BookOpen, Heart, Laptop, Leaf, MapPin,
  Search, Shirt, ShoppingBag, Sparkles, Store, Wrench,
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { getErrorMessage, productApi } from '../services/api';

const categories = [
  { label: 'Everything', value: 'ALL', icon: Sparkles },
  { label: 'Books', value: 'TEXTBOOKS', icon: BookOpen },
  { label: 'Tech', value: 'ELECTRONICS', icon: Laptop },
  { label: 'Clothing', value: 'CLOTHING', icon: Shirt },
  { label: 'Services', value: 'SERVICES', icon: Wrench },
  { label: 'Eco finds', value: 'ECO_FRIENDLY', icon: Leaf },
];

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [sortOrder, setSortOrder] = useState('recent');
  const [ecoOnly, setEcoOnly] = useState(false);
  const { addToCart } = useCart();

  useEffect(() => {
    let cancelled = false;

    const loadProducts = async () => {
      setLoading(true);
      setLoadError('');
      try {
        const response = await productApi.getAll();
        if (!cancelled && response.data.success) setProducts(response.data.data);
      } catch (error) {
        if (!cancelled) setLoadError(getErrorMessage(error, 'Could not load campus listings.'));
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    loadProducts();
    return () => { cancelled = true; };
  }, [reloadKey]);

  const visibleProducts = useMemo(() => {
    const query = search.trim().toLowerCase();
    const matches = products.filter((product) => {
      const text = `${product.title} ${product.description || ''} ${product.category || ''} ${product.seller?.fullName || ''}`.toLowerCase();
      const matchesCategory = activeCategory === 'ALL'
        || (activeCategory === 'ECO_FRIENDLY' ? product.ecoFriendly : product.category === activeCategory);
      return matchesCategory && (!ecoOnly || product.ecoFriendly) && (!query || text.includes(query));
    });

    if (sortOrder === 'price-low') return matches.sort((a, b) => Number(a.price) - Number(b.price));
    if (sortOrder === 'price-high') return matches.sort((a, b) => Number(b.price) - Number(a.price));
    return matches;
  }, [products, search, activeCategory, ecoOnly, sortOrder]);

  return (
    <div className="home-page">
      <div className="home-announcement">
        <span><MapPin size={14} /> Made for our campus & the neighborhood</span>
        <span className="announcement-note">Good things travel better nearby.</span>
      </div>

      <section className="home-hero" aria-labelledby="home-title">
        <img
          className="home-hero-image"
          src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=2000&q=85"
          alt="Shelves of books in a neighborhood bookstore"
        />
        <div className="home-hero-shade" />
        <div className="home-hero-content">
          <span className="home-eyebrow"><Store size={15} /> THE CAMPUS COMMUNITY MARKET</span>
          <h1 id="home-title">Campus finds,<br />closer to home.</h1>
          <p>Pass it on, find your next favorite, and meet the people behind the good stuff.</p>
          <a className="home-hero-cta" href="#listings">Find your next find <ArrowRight size={18} /></a>
          <div className="home-hero-proof"><BadgeCheck size={16} /> A trusted little corner of the community</div>
        </div>
        <div className="hero-side-note">STUDENTS <span>·</span> FACULTY <span>·</span> LOCAL MAKERS</div>
      </section>

      <div className="home-content">
        <section className="home-category-section" aria-label="Shop by category">
          <div className="home-section-kicker">A good place to start</div>
          <div className="home-category-list">
            {categories.map(({ label, value, icon: Icon }) => (
              <button
                className={`home-category ${activeCategory === value ? 'is-active' : ''}`}
                key={value}
                type="button"
                aria-pressed={activeCategory === value}
                onClick={() => setActiveCategory(value)}
              >
                <Icon size={18} strokeWidth={1.8} /> {label}
              </button>
            ))}
          </div>
        </section>

        <section className="home-listings" id="listings" aria-labelledby="listings-title">
          <div className="home-listings-heading">
            <div>
              <div className="home-section-kicker">Fresh from around here</div>
              <h2 id="listings-title">Finds with a familiar feel.</h2>
              <p>Good stuff from people just around the corner.</p>
            </div>
            <Link className="home-view-all" to="/marketplace">Explore marketplace <ArrowRight size={17} /></Link>
          </div>

          <div className="home-toolbar">
            <label className="home-search">
              <Search size={18} aria-hidden="true" />
              <input
                type="search"
                aria-label="Search campus listings"
                placeholder="Try “textbooks” or “bike”"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            <label className="home-sort">
              <ArrowDownUp size={16} aria-hidden="true" />
              <span className="visually-hidden">Sort listings</span>
              <select value={sortOrder} onChange={(event) => setSortOrder(event.target.value)}>
                <option value="recent">Recently added</option>
                <option value="price-low">Price: low to high</option>
                <option value="price-high">Price: high to low</option>
              </select>
            </label>
            <label className="home-eco-toggle">
              <input type="checkbox" checked={ecoOnly} onChange={(event) => setEcoOnly(event.target.checked)} />
              <Leaf size={16} /> Eco-friendly
            </label>
          </div>

          {loading ? (
            <div className="home-state" role="status">Finding the latest listings…</div>
          ) : loadError ? (
            <div className="home-state home-state-error" role="alert">
              <p>{loadError}</p>
              <button type="button" onClick={() => setReloadKey((key) => key + 1)}>Try again</button>
            </div>
          ) : visibleProducts.length === 0 ? (
            <div className="home-state">
              <ShoppingBag size={26} />
              <p>{products.length ? 'No listings match those filters.' : 'The shelves are waiting for their first listing.'}</p>
              <Link to="/sell">Share something with the community <ArrowRight size={16} /></Link>
            </div>
          ) : (
            <div className="home-product-grid">
              {visibleProducts.slice(0, 8).map((product) => (
                <article className="home-product" key={product.id}>
                  <Link className="home-product-image" to={`/products/${product.id}`} aria-label={`View ${product.title}`}>
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.title} loading="lazy" />
                    ) : (
                      <span className="home-image-placeholder"><Store size={28} /></span>
                    )}
                    {product.ecoFriendly && <span className="home-eco-label"><Leaf size={12} /> Pre-loved</span>}
                    <span className="home-product-heart" aria-hidden="true"><Heart size={16} /></span>
                  </Link>
                  <div className="home-product-info">
                    <div className="home-product-meta">
                      <span>{product.category?.replace(/_/g, ' ') || 'Community find'}</span>
                      {product.conditionName && <span>{product.conditionName}</span>}
                    </div>
                    <Link className="home-product-title" to={`/products/${product.id}`}>{product.title}</Link>
                    <div className="home-product-seller">
                      <span>{product.seller?.fullName || 'Community seller'}</span>
                      {product.seller?.verified && <BadgeCheck size={14} aria-label="Verified seller" />}
                    </div>
                    <div className="home-product-bottom">
                      <strong>R {Number(product.price ?? 0).toFixed(2)}</strong>
                      <button
                        type="button"
                        aria-label={`Add ${product.title} to cart`}
                        disabled={product.available === false}
                        onClick={() => addToCart(product)}
                      >
                        <ShoppingBag size={16} /> <span>{product.available === false ? 'Sold' : 'Add'}</span>
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
          {!loading && !loadError && visibleProducts.length > 8 && (
            <div className="home-more-link"><Link to="/marketplace">See all {visibleProducts.length} finds <ArrowRight size={16} /></Link></div>
          )}
        </section>

        <section className="home-community-band">
          <div className="community-band-mark"><Leaf size={23} /></div>
          <div>
            <span>Keep good things in good hands</span>
            <h2>Buy nearby. Pass it on. Make this place yours.</h2>
          </div>
          <Link to="/bulletin">Meet the community <ArrowRight size={17} /></Link>
        </section>

        <section className="home-trust-row" aria-label="Marketplace values">
          <div><BadgeCheck size={19} /><span><strong>People first</strong><small>Neighbors, not strangers</small></span></div>
          <div><Leaf size={19} /><span><strong>Less waste</strong><small>Give good things another life</small></span></div>
          <div><MapPin size={19} /><span><strong>Close by</strong><small>Made for the campus community</small></span></div>
        </section>
      </div>
    </div>
  );
};

export default Home;