import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, ShieldCheck, Leaf, Star, MapPin, ArrowLeft, Heart, Share2, CheckCircle2, Package, MessageCircle } from 'lucide-react';
import { productApi, getErrorMessage } from '../services/api';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

const money = (n) => `R ${Number(n || 0).toFixed(2)}`;

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const toast = useToast();
  const [product,setProduct] = useState(null);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState('');
  const [liked,setLiked] = useState(() => JSON.parse(localStorage.getItem('cs_wishlist')||'[]').includes(String(id)));

  useEffect(() => {
    let cancelled=false;
    productApi.getById(id).then(res=>{ if(!cancelled && res.data.success) setProduct(res.data.data); })
      .catch(err=>!cancelled && setError(getErrorMessage(err,'Could not load this listing.')))
      .finally(()=>!cancelled && setLoading(false));
    return ()=>{cancelled=true};
  },[id]);

  const toggleLike=()=>{
    const current=JSON.parse(localStorage.getItem('cs_wishlist')||'[]');
    const next=current.includes(String(id))?current.filter(x=>x!==String(id)):[...current,String(id)];
    localStorage.setItem('cs_wishlist',JSON.stringify(next)); setLiked(!liked);
    toast.info(!liked?'Saved to your local wishlist.':'Removed from wishlist.');
  };

  if(loading) return <div className="state-message"><div className="loading-pulse"/><p>Opening listing…</p></div>;
  if(error || !product) return <div className="state-message state-error"><p>{error || 'Product not found.'}</p><Link className="secondary-btn" to="/marketplace"><ArrowLeft size={16}/> Back to marketplace</Link></div>;

  const seller=product.seller||{};
  const rating=Number(seller.rating||0);
  const buy=()=>{addToCart(product);navigate('/cart')};

  return (
    <div className="product-page">
      <Link to="/marketplace" className="back-link"><ArrowLeft size={17}/> Back to marketplace</Link>
      <div className="product-layout">
        <div className="product-visual">
          {product.imageUrl?<img src={product.imageUrl} alt={product.title}/>:<div className="product-placeholder"><ShoppingBag size={64}/><span>Community find</span></div>}
          {product.ecoFriendly && <span className="floating-badge"><Leaf size={14}/> Eco-friendly</span>}
          <button className={`wishlist-btn ${liked?'liked':''}`} onClick={toggleLike} aria-label="Save listing"><Heart size={21} fill={liked?'currentColor':'none'}/></button>
        </div>
        <div className="product-info">
          <div className="product-tags"><span>{product.category?.replace(/_/g,' ')}</span><span>{product.conditionName || 'Good condition'}</span>{product.available===false&&<span className="sold-tag">Sold</span>}</div>
          <h1>{product.title}</h1>
          <div className="product-price">{money(product.price)}</div>
          <p className="product-description">{product.description || 'A community listing shared by a local seller.'}</p>
          <div className="seller-card">
            <div className="seller-avatar">{seller.fullName?.charAt(0)?.toUpperCase()||'C'}</div>
            <div><span>LISTED BY</span><strong>{seller.fullName||'Community seller'} {seller.verified&&<ShieldCheck size={16}/>}</strong><small>{seller.institutionOrBusiness||seller.role||'Community member'}</small></div>
            <div className="seller-rating"><Star size={15} fill="currentColor"/>{rating.toFixed(1)}<small>{seller.totalRatings||0} reviews</small></div>
          </div>
          <div className="product-facts">
            <div><MapPin size={18}/><span><b>Pickup</b><small>{product.location||'Arrange with seller'}</small></span></div>
            <div><Package size={18}/><span><b>Availability</b><small>{product.available===false?'No longer available':'Available now'}</small></span></div>
            <div><CheckCircle2 size={18}/><span><b>Community checked</b><small>Verified marketplace account</small></span></div>
          </div>
          <div className="product-actions">
            <button className="secondary-btn" disabled={product.available===false} onClick={()=>{addToCart(product);toast.success('Added to your cart.')}}><ShoppingBag size={19}/> Add to cart</button>
            <button className="primary-btn" disabled={product.available===false} onClick={buy}>Buy now <ArrowRightIcon/></button>
          </div>
          <div className="product-share"><button onClick={()=>navigator.share?.({title:product.title,url:window.location.href})}><Share2 size={16}/> Share</button><span><MessageCircle size={15}/> Chat details are arranged locally</span></div>
        </div>
      </div>
    </div>
  );
}
function ArrowRightIcon(){return <span aria-hidden="true">→</span>}
